<?php

namespace App\Core;

class Router
{
    public function run()
    {
        $path = isset($_GET['url']) ? trim((string) $_GET['url'], '/') : '';
        $segments = $path === '' ? ['home', 'index'] : explode('/', filter_var($path, FILTER_SANITIZE_URL));

        $controllerSegment = $segments[0] ?: 'home';
        $action = $segments[1] ?? 'index';
        $params = array_slice($segments, 2);

        $controllerName = 'App\\Controllers\\' . ucfirst($controllerSegment) . 'Controller';

        if (!class_exists($controllerName)) {
            $this->render404("Le controleur '$controllerName' est introuvable.");
            return;
        }

        $controller = new $controllerName();
        if (!method_exists($controller, $action)) {
            $this->render404("La methode '$action' n'existe pas.");
            return;
        }

        call_user_func_array([$controller, $action], $params);
    }

    private function render404(string $message): void
    {
        http_response_code(404);
        echo "<h1>404</h1><p>$message</p>";
    }
}